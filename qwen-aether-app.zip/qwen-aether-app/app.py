#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Qwen + Aether 技能助手 —— 魔搭创空间 (ModelScope Studio) 部署
- 自动扫描 skills/ 下的全部技能 (SKILL.md)
- 支持「自动匹配技能」或手动指定技能
- 流式输出，Gradio 界面
- 端口固定 7860
"""
import os
import re
import glob
import threading

import torch
import gradio as gr
from modelscope import AutoModelForCausalLM, AutoTokenizer
from transformers import TextIteratorStreamer

# ----------------------------------------------------------------------
# 配置（可通过环境变量覆盖）
# ----------------------------------------------------------------------
# 默认模型为 CPU 免费档可流畅运行的 1.5B 版本，开箱即用；
# 若部署到免费 GPU(xGPU 16G)，把环境变量 MODEL_ID 改成
# "Qwen/Qwen2.5-7B-Instruct" 可获得更强能力（见 README 升级说明）。
MODEL_ID = os.environ.get("MODEL_ID", "Qwen/Qwen2.5-1.5B-Instruct")
SKILLS_DIR = os.environ.get("SKILLS_DIR", "skills")
MAX_NEW_TOKENS = int(os.environ.get("MAX_NEW_TOKENS", "2048"))

BASE_SYSTEM = (
    "你是 Aether（扶摇），一名面向 Linux 服务器运维与 ESP32 硬件/固件开发的底层调试助手。"
    "结果导向，对 bug 零容忍，优先给出可直接复制执行的命令、完整代码和分步操作。"
    "如果下面提供了技能说明，请严格遵循其中的流程、铁律与安全要求；"
    "不确定或无法验证的内容要明确说明，绝不能编造命令输出或执行结果。"
)


# ----------------------------------------------------------------------
# 技能加载与匹配
# ----------------------------------------------------------------------
def parse_skill(path):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", text, re.DOTALL)
    meta, body = {}, text
    if m:
        for line in m.group(1).split("\n"):
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
        body = m.group(2)
    name = meta.get("name", os.path.basename(os.path.dirname(path)))
    return {
        "name": name,
        "description": meta.get("description", ""),
        "body": body.strip(),
    }


def load_skills():
    skills = []
    for path in sorted(glob.glob(os.path.join(SKILLS_DIR, "*", "SKILL.md"))):
        try:
            skills.append(parse_skill(path))
        except Exception as e:  # 单个技能解析失败不影响整体
            print(f"[warn] 解析技能失败 {path}: {e}")
    return skills


SKILLS = load_skills()
SKILL_MAP = {s["name"]: s for s in SKILLS}
print(f"已加载 {len(SKILLS)} 个技能: {[s['name'] for s in SKILLS]}")


def _keywords(text):
    """从文本提取关键词：英文技术词 + 数字串(状态码/端口) + 中文 2~4 字滑动 n-gram。"""
    kws = set()
    for w in re.findall(r"[A-Za-z][A-Za-z0-9_.\-]+", text):
        if len(w) >= 2:
            kws.add(w)
    for w in re.findall(r"\d{2,5}", text):
        kws.add(w)
    for seg in re.findall(r"[\u4e00-\u9fa5]+", text):
        for size in (2, 3, 4):
            for i in range(len(seg) - size + 1):
                kws.add(seg[i:i + size])
    return kws


def match_skill(user_msg):
    """根据用户消息与技能（名称+描述）的关键词重叠打分，返回最相关技能。"""
    best, best_score = None, 0
    msg_lower = user_msg.lower()
    for s in SKILLS:
        score = 0
        for t in _keywords(s["name"] + " " + s["description"]):
            if t.lower() in msg_lower:
                score += len(t)
        if score > best_score:
            best, best_score = s, score
    return best


def build_system(skill_name, user_msg):
    sys_text = BASE_SYSTEM
    chosen = None
    if skill_name and skill_name != "无":
        if skill_name == "自动匹配":
            chosen = match_skill(user_msg)
        else:
            chosen = SKILL_MAP.get(skill_name)
    if chosen:
        sys_text += (
            "\n\n# 当前启用的技能：" + chosen["name"] +
            "\n请严格按以下技能说明执行：\n\n" + chosen["body"]
        )
    return sys_text, (chosen["name"] if chosen else "未启用技能")


# ----------------------------------------------------------------------
# 模型加载
# ----------------------------------------------------------------------
print(f"正在加载模型 {MODEL_ID} ...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    torch_dtype=dtype,
    device_map="auto",
)
model.eval()
print("模型加载完成，设备:", next(model.parameters()).device)


# ----------------------------------------------------------------------
# 对话生成（流式）
# ----------------------------------------------------------------------
def generate(history, skill_name):
    if not history or history[-1].get("role") != "user":
        yield history, gr.update()
        return
    user_msg = history[-1]["content"]
    system_prompt, active_skill = build_system(skill_name, user_msg)

    messages = [{"role": "system", "content": system_prompt}]
    for turn in history:
        messages.append({"role": turn["role"], "content": turn["content"]})

    inputs_text = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    inputs = tokenizer([inputs_text], return_tensors="pt").to(model.device)

    streamer = TextIteratorStreamer(
        tokenizer, skip_prompt=True, skip_special_tokens=True
    )
    gen_kwargs = dict(
        **inputs,
        max_new_tokens=MAX_NEW_TOKENS,
        do_sample=True,
        temperature=0.7,
        top_p=0.8,
        repetition_penalty=1.05,
        streamer=streamer,
        pad_token_id=tokenizer.eos_token_id,
    )
    thread = threading.Thread(target=model.generate, kwargs=gen_kwargs)
    thread.start()

    history.append({"role": "assistant", "content": ""})
    for chunk in streamer:
        history[-1]["content"] += chunk
        yield history, f"当前技能：{active_skill}"
    thread.join()


def user_submit(msg, history):
    return "", history + [{"role": "user", "content": msg}]


# ----------------------------------------------------------------------
# 界面
# ----------------------------------------------------------------------
skill_choices = ["自动匹配"] + [s["name"] for s in SKILLS] + ["无"]

with gr.Blocks(title="Qwen + Aether 技能助手", theme=gr.themes.Soft()) as demo:
    gr.Markdown("# 🛠️ Qwen + Aether 技能助手")
    gr.Markdown(
        "面向 **Linux 服务器运维 + ESP32 固件开发** 的千问助手，内置 "
        f"{len(SKILLS)} 个技能。默认自动匹配，也可手动指定技能。"
    )
    with gr.Row():
        skill_dd = gr.Dropdown(
            skill_choices, value="自动匹配", label="技能选择",
            scale=3,
        )
        skill_status = gr.Textbox(
            label="状态", value="当前技能：待触发", interactive=False, scale=2,
        )
    chatbot = gr.Chatbot(type="messages", height=520, label="对话")
    with gr.Row():
        msg_box = gr.Textbox(
            placeholder="描述你的问题，例如：帮我巡检一下磁盘 / 查下 ESP32 蓝牙扫描 …",
            scale=8, show_label=False,
        )
        send_btn = gr.Button("发送", variant="primary", scale=1)
    with gr.Row():
        clear_btn = gr.Button("清空对话")

    msg_box.submit(user_submit, [msg_box, chatbot], [msg_box, chatbot]).then(
        generate, [chatbot, skill_dd], [chatbot, skill_status]
    )
    send_btn.click(user_submit, [msg_box, chatbot], [msg_box, chatbot]).then(
        generate, [chatbot, skill_dd], [chatbot, skill_status]
    )
    clear_btn.click(lambda: [], None, chatbot)

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860)
