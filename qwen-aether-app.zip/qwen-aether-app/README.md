---
title: Qwen Aether 技能助手
emoji: 🛠️
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 5.29.0
app_file: app.py
pinned: false
---

# Qwen + Aether 技能助手

面向 **Linux 服务器运维 + ESP32 固件开发** 的千问助手，内置 11 个 Aether 技能包，
默认自动匹配技能，也可手动指定。

## 功能

- 自动扫描 `skills/` 下的全部技能（每个技能一个含 `SKILL.md` 的目录）
- 「自动匹配」根据问题关键词匹配最相关技能；也可下拉手动指定
- 流式输出，Gradio 聊天界面

## 内置技能

| 技能 | 用途 |
|---|---|
| linux-server-ops | 磁盘/分区/迁移/备份/SSH/穿透/服务排错 |
| esp32-raider-firmware | 屏幕/UI/中文渲染/WiFi/BLE/刷写回滚 |
| shell-automation | 脚本规范、批量执行、后台任务、日志解析 |
| git-repo-manager | 分支/回滚/镜像克隆/密钥/打包直链 |
| project-doc-task | 任务三态清单、版本变更、双报告 |
| risk-safety-check | 高危二次确认、磁盘校验、SSH 防锁死 |
| network-diagnosis | 分层排障、穿透三件套、网络专项 |
| code-bugfix-batch | 批量定位、一次编译、报错对照表 |
| docker-container | 容器/镜像/卷/迁移/排错 |
| nginx-reverse-proxy | 反代模板、SSL、404/502/504 |
| archive-package | 打包规范、技能包校验 |

## 默认配置（免费 CPU）

- 资源：`platform/2v-cpu-16g-mem`（免费）
- 模型：`Qwen/Qwen2.5-1.5B-Instruct`
- 端口：7860

## 升级到免费 GPU + 更强模型（可选）

1. 先在魔搭申请加入「xGPU Playground」组织（免费）。
2. 用本仓库的 `ms_deploy.gpu.json` 内容覆盖 `ms_deploy.json`：
   - 资源变为 `xgpu/8v-cpu-32g-mem-16g`（16G 显存，免费）
   - 模型变为 `Qwen/Qwen2.5-7B-Instruct`
3. 重新部署即可。

## 本地运行

```bash
pip install -r requirements.txt
python app.py
```
然后访问 http://localhost:7860
